# 足球概率实验室（新手版）

## 手机上使用：先部署一次，以后只需打开网址

1. 创建 GitHub 账号（github.com）和 Streamlit Community Cloud 账号（share.streamlit.io）。
2. 在 GitHub 新建一个仓库，例如 `football-model`。建议选 Private；部署时按 Streamlit 当前要求授权仓库访问。
3. 在仓库页面点击 Add file → Upload files，上传 `app.py`、`requirements.txt`，然后 Commit changes。
4. 访问 https://share.streamlit.io/，选择 Create app / Deploy an app，选中刚才的 GitHub 仓库、分支 main、主文件 `app.py`，点击 Deploy。
5. 等待构建完成，打开生成的网址。iPhone Safari 中选择“分享”→“添加到主屏幕”。

如果手机浏览器上传文件不方便，可以先在电脑完成 GitHub 上传和首次部署，后续手机即可使用。

## 使用说明

- 选择联赛和赛季，选择主客队、体彩主队让球数，即可计算普通胜平负与让球胜平负概率。
- 回测使用按时间滚动的历史数据，不会用赛后信息预测赛前结果。
- 基础模型采用联赛平均进球、球队近期主客场表现及平滑处理，使用独立泊松概率矩阵。
- 它**不支持**跨联赛对阵、欧冠、杯赛、实时首发和伤停；这些属于后续升级功能。
- 首次部署免费额度和仓库可见性以 Streamlit 当时的服务条款为准。
- 模型概率不保证准确，不能用于证明任何投注策略必然盈利。
